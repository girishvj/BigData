package upgrad.ml_Analytics;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.ml.clustering.KMeans;
import org.apache.spark.ml.clustering.KMeansModel;
import org.apache.spark.ml.evaluation.ClusteringEvaluator;
import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.expressions.Window;
import org.apache.spark.sql.expressions.WindowSpec;

public class SaavnClusteringUserData {
	public static SparkSession spark;
	
	public static void main(String[] args) {

		Logger.getLogger("org").setLevel(Level.ERROR);
		Logger.getLogger("akka").setLevel(Level.ERROR);

		
		// Create a SparkSession at Local
		spark = SparkSession.builder()
				.appName("SaavnAnalytics")
				/*.master("local[*]")*/
				.getOrCreate();

		// Loads data sample100mb.csv from /data
		Dataset<Row> rawDataset = spark.read().option("header", "true").csv(args[0])
			.toDF("user_id","timestamp","song_id","date_col");
		
		//Load new meta data -- from location C:\data\new meta data
		Dataset<Row> artistDataset = spark.read().option("header", "true").csv(args[1])//new meta data
			.toDF("song_id","artist_id");
		
		//Load new notification -- from location C:\data\notification_clicks
		Dataset<Row> notificationClicks = spark.read().option("header", "true").csv(args[2])//notification_clicks
			.toDF("notification_id","user_id","date_col");
		
		//Load new notification -- from location C:\data\notification_actor.csv
    	Dataset<Row> artistNotificationDataset = spark.read().option("header", "true").csv(args[3]) //notification_actor.csv
    		.toDF("notification_id","artist_id");
 		
		// Ignore rows having null values
		Dataset<Row> datasetClean = rawDataset.na().drop();
		datasetClean.printSchema();
		
		datasetClean = datasetClean.withColumn("modified_date",functions.date_format(functions.to_date(datasetClean.col("date_col"), "yyyymmdd"), "yyyy-MM-dd"));
		datasetClean.show();
		
		Dataset<Row> datasetdbf = datasetClean.withColumn("last_lisen", functions.datediff(
			functions.current_date(),
			datasetClean.col("modified_date")));
		
		// Recency, that measures how recently a user last listened to a particular song
		Dataset<Row> datasetRecency = datasetdbf.groupBy("user_id")
				.agg(functions.min("last_lisen").alias("recency"));
		datasetRecency.show();
		
		// Frequency, that measures frequency of the number of times a song was heard by performing a aggregation.
		Dataset<Row> datasetFreq = datasetdbf.groupBy("user_id", "date_col").count().groupBy("user_id")
				.agg(functions.count("*").alias("frequency"));
		datasetFreq.show();
		
		Dataset<Row> datasetMf = datasetRecency
				.join(datasetFreq, datasetRecency.col("user_id").equalTo(datasetFreq.col("user_id")), "inner")
				.drop(datasetFreq.col("user_id"));
		datasetMf.show();	
		
		Dataset<Row> datasetwithsong = datasetMf
				.join(datasetdbf, datasetMf.col("user_id").equalTo(datasetdbf.col("user_id")), "inner")
				.drop(datasetdbf.col("user_id"));
		datasetwithsong.show();	
		
		StringIndexer indexer = new StringIndexer()
				  .setInputCol("song_id")
				  .setOutputCol("song_id_indexed");

		Dataset<Row> datasetwithsongindexed = indexer.fit(datasetwithsong).transform(datasetwithsong);
		datasetwithsongindexed.show();
		
		VectorAssembler assembler = new VectorAssembler()
				  .setInputCols(new String[] {"recency", "frequency","last_lisen"}).setOutputCol("features");
				
		Dataset<Row> datasetRfm = assembler.transform(datasetwithsong);
		datasetRfm.show();
		 
		// Trains a k-means model
		KMeans kmeans = new KMeans().setK(5);
		KMeansModel model = kmeans.fit(datasetRfm);
		
		// Make predictions
		Dataset<Row> predictions = model.transform(datasetRfm);
		//predictions.show();
		
		Dataset<Row> clusterUsers = predictions.groupBy("prediction")
			.agg(functions.count("user_id").alias("cluster_user_count"));
		//clusterUsers.show();
		
		Dataset<Row> predictionswithArtist = predictions
				.join(artistDataset, predictions.col("song_id").equalTo(artistDataset.col("song_id")), "inner")
				.drop(artistDataset.col("song_id"));
		//predictionswithArtist.show();
			
		Dataset<Row> datasetcnt = predictionswithArtist.groupBy("prediction","artist_id").count().orderBy(functions.asc("prediction"),functions.desc("count"));
		//datasetcnt.show();
		
		WindowSpec  window = Window.partitionBy("prediction").orderBy(functions.desc("count"));

		Dataset<Row> datasetcntRnk =  datasetcnt.withColumn("rn", functions.row_number().over(window));
		//datasetcntRnk.show();
		//datasetcntRnk.printSchema();
		
		Dataset<Row> datasetcntRnkfilterd =  datasetcntRnk.filter(x -> x.getInt(3) == 1);
		//datasetcntRnkfilterd.show();
		
		Dataset<Row> predWithcluserusers = datasetcntRnkfilterd
		.join(clusterUsers, datasetcntRnkfilterd.col("prediction").equalTo(clusterUsers.col("prediction")), "inner")
		.drop(clusterUsers.col("prediction"));
		//predWithcluserusers.show();
	
		Dataset<Row> predNotArtistJoined = predWithcluserusers
			.join(artistNotificationDataset, predWithcluserusers.col("artist_id").equalTo(artistNotificationDataset.col("artist_id")), "inner")
			.drop(artistNotificationDataset.col("artist_id"));
		//predNotArtistJoined.show();
		
		Dataset<Row> notificationclickcnt = notificationClicks.groupBy("notification_id").agg(functions.count("user_id").alias("user_notificaiton_count"));
		//notificationclickcnt.show();
		
		Dataset<Row> predNotArtistJoinedwithNotiUsercount = predNotArtistJoined
			.join(notificationclickcnt, predNotArtistJoined.col("notification_id").equalTo(notificationclickcnt.col("notification_id")), "inner")
			.drop(notificationclickcnt.col("notification_id"));
		//predNotArtistJoinedwithNotiUsercount.show();
		
		Dataset<Row> predictedClusterUserCount = predictions.groupBy("prediction").agg(functions.count("user_id").alias("prediction_user_count"));
		//predictedClusterUserCount.show();
		
		Dataset<Row> predNotArtistJoinedwithNotiUsercount1 = predNotArtistJoinedwithNotiUsercount
			.join(predictedClusterUserCount, predNotArtistJoinedwithNotiUsercount.col("prediction").equalTo(predictedClusterUserCount.col("prediction")), "inner")
			.drop(predictedClusterUserCount.col("prediction"));
		//predNotArtistJoinedwithNotiUsercount1.show();
		
		Dataset<Row> ctr = predNotArtistJoinedwithNotiUsercount1.withColumn("CTR", (predNotArtistJoinedwithNotiUsercount1.col("prediction_user_count").divide(predNotArtistJoinedwithNotiUsercount1.col("user_notificaiton_count"))).multiply(100));
		ctr.show();
		
		// Evaluate clustering by computing Silhouette score
		ClusteringEvaluator evaluator = new ClusteringEvaluator();
		double silhouette = evaluator.evaluate(predictions);
		
		System.out.println("Silhouette with squared euclidean distance = " + silhouette);
		
		// Shows the result
		Vector[] centers = model.clusterCenters();
		System.out.println("Cluster Centers: ");
		
		for (Vector center : centers) {	
			System.out.println(center);
		}
		spark.stop();
	}
}	
